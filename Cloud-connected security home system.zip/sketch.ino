#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>

const char* WIFI_SSID    = "Wokwi-GUEST";
const char* WIFI_PASS    = "";
const char* AIO_SERVER   = "io.adafruit.com";
const int   AIO_PORT     = 1883;
const char* AIO_USERNAME = "YOUR_AIO_USERNAME";
const char* AIO_KEY      = "YOUR_AIO_KEY";

#define PIN_TRIG          5 
#define PIN_ECHO         18
#define PIN_PIR          13
#define PIN_GAS_AOUT     34
#define PIN_GAS_DOUT     35
#define PIN_FLAME_AOUT   36
#define PIN_FLAME_DOUT   39
#define PIN_DHT           4
#define PIN_SDA          21
#define PIN_SCL          22
#define PIN_BUZZER       25
#define PIN_RELAY1       26
#define PIN_RELAY2       33
#define PIN_LED_GREEN    14
#define PIN_LED_YELLOW   27
#define PIN_LED_ORANGE   15
#define PIN_LED_RED      19
#define PIN_BUTTON       32

#define OLED_ADDR  0x3C
#define OLED_W      128
#define OLED_H       64

#define DHT_MODEL  DHT22

#define DIST_ALERT_CM        80   
#define GAS_ALERT_LOW      1000   
#define GAS_WARNING        2000   
#define GAS_CRITICAL       3000  
#define FLAME_AOUT_ALERT   2500  
#define TEMP_ALERT_C         38  
#define TEMP_WARNING_C       45 
#define TEMP_CRITICAL_C      55

#define MS_SENSOR        200
#define MS_PUBLISH      3000
#define MS_MQTT_RETRY   5000
#define MS_DEBOUNCE      300

enum SystemState : uint8_t {
    STATE_SAFE     = 0,
    STATE_ALERT    = 1,
    STATE_WARNING  = 2,
    STATE_CRITICAL = 3
};

const char* STATE_NAME[] = { "SAFE", "ALERT", "WARNING", "CRITICAL" };

Adafruit_SSD1306 oled(OLED_W, OLED_H, &Wire, -1);
DHT              dht(PIN_DHT, DHT_MODEL);
WiFiClient       wifiClient;
PubSubClient     mqtt(wifiClient);

bool        armed        = false;
bool        lastBtn      = false;
SystemState sysState     = STATE_SAFE;
SystemState lastState    = STATE_SAFE;

long  rDist       = 999;
bool  rMotion     = false;
int   rGasAout    = 0;
bool  rGasDout    = false;
int   rFlameAout  = 4095;
bool  rFlameDout  = false;
bool  rFlame      = false;
float rTemp       = 0.0f;
float rHum        = 0.0f;
bool  sensorFault = false; 

unsigned long tSensor  = 0;
unsigned long tPublish = 0;
unsigned long tMqtt    = 0;
unsigned long tBtn     = 0;

struct Note { int freq; int ms; };

Note mSafe[]     = {{262,120},{330,120},{392,120},{523,300}};
Note mAlert[]    = {{440,150},{0,100},{440,150}};
Note mWarning[]  = {{523,100},{0,70},{523,100},{0,70},{523,100},{0,70},{523,100}};
Note mCritical[] = {
    {880,70},{0,30},{523,70},{0,30},
    {880,70},{0,30},{523,70},{0,30},
    {880,70},{0,30},{523,70},{0,30},
    {880,70},{0,30},{523,70},{0,30}
};

struct BuzzerSM {
    Note* seq = nullptr; int len = 0;
    int pos = 0; unsigned long next = 0; bool active = false;
} buz;

void buzPlay(SystemState st) {
    if (buz.active) ledcDetach(PIN_BUZZER);
    buz.pos = 0; buz.next = millis(); buz.active = true;
    switch (st) {
        case STATE_SAFE:     buz.seq = mSafe;     buz.len = sizeof(mSafe)     / sizeof(Note); break;
        case STATE_ALERT:    buz.seq = mAlert;    buz.len = sizeof(mAlert)    / sizeof(Note); break;
        case STATE_WARNING:  buz.seq = mWarning;  buz.len = sizeof(mWarning)  / sizeof(Note); break;
        case STATE_CRITICAL: buz.seq = mCritical; buz.len = sizeof(mCritical) / sizeof(Note); break;
    }
}

void buzRun() {
    if (!buz.active || millis() < buz.next) return;
    if (buz.pos >= buz.len) {
        ledcDetach(PIN_BUZZER);
        buz.active = false;
        return;
    }
    Note& n = buz.seq[buz.pos++];
    if (n.freq == 0) ledcDetach(PIN_BUZZER);
    else { ledcAttach(PIN_BUZZER, n.freq, 8); ledcWrite(PIN_BUZZER, 128); }
    buz.next = millis() + n.ms;
}

long readDistance() {
    digitalWrite(PIN_TRIG, LOW);  delayMicroseconds(2);
    digitalWrite(PIN_TRIG, HIGH); delayMicroseconds(10);
    digitalWrite(PIN_TRIG, LOW);
    long us = pulseIn(PIN_ECHO, HIGH, 30000UL);
    return (us == 0) ? 999 : (us * 17L) / 1000L;
}

void readAllSensors() {
    sensorFault = false;

    rDist      = readDistance();
    rMotion    = (digitalRead(PIN_PIR) == HIGH);
    rGasAout   = analogRead(PIN_GAS_AOUT);
    rGasDout   = (digitalRead(PIN_GAS_DOUT) == HIGH);
    rFlameAout = analogRead(PIN_FLAME_AOUT);
    rFlameDout = (digitalRead(PIN_FLAME_DOUT) == LOW);  
    rFlame     = rFlameDout || (rFlameAout < FLAME_AOUT_ALERT);

    float t = dht.readTemperature();
    float h = dht.readHumidity();

    if (isnan(t) || isnan(h)) {
        sensorFault = true;   // triggers white LED
        Serial.println("[FAULT] DHT22 returned NaN — check wiring");
    } else {
        rTemp = t;
        rHum  = h;
    }

    if (rDist == 999) {
        Serial.println("[WARN] HC-SR04 timeout — no echo received");
    }
}

SystemState classifyState() {
    if (!armed) return STATE_SAFE;

    if (rFlame
     || rGasDout
     || rGasAout  > GAS_CRITICAL
     || (int)rTemp > TEMP_CRITICAL_C) {
        return STATE_CRITICAL;
    }

    if (rGasAout  > GAS_WARNING
     || (int)rTemp > TEMP_WARNING_C) {
        return STATE_WARNING;
    }

    if (rGasAout  > GAS_ALERT_LOW
     || (int)rTemp > TEMP_ALERT_C
     || (rDist > 0 && rDist < DIST_ALERT_CM)) {
        return STATE_ALERT;
    }

    return STATE_SAFE;
}

void setLEDs() {

    digitalWrite(PIN_LED_GREEN,  LOW);
    digitalWrite(PIN_LED_YELLOW, LOW);
    digitalWrite(PIN_LED_ORANGE, LOW);
    digitalWrite(PIN_LED_RED,    LOW);

    if (!armed) {
        bool blink = (millis() / 800) % 2 == 0;
        digitalWrite(PIN_LED_GREEN, blink ? HIGH : LOW);
        return;  // nothing else should light while disarmed
    }


    if (sysState == STATE_CRITICAL) {
        digitalWrite(PIN_LED_RED, HIGH);

    } else if (sysState == STATE_WARNING || sensorFault) {
        digitalWrite(PIN_LED_ORANGE, HIGH);

    } else if (sysState == STATE_ALERT || rMotion) {
        digitalWrite(PIN_LED_YELLOW, HIGH);

    } else {
        digitalWrite(PIN_LED_GREEN, HIGH);
    }
}

void setRelays() {
    digitalWrite(PIN_RELAY1, (armed && sysState >= STATE_WARNING)  ? LOW : HIGH);
    digitalWrite(PIN_RELAY2, (armed && sysState == STATE_CRITICAL) ? LOW : HIGH);
}


void drawOLED() {
    char buf[22];
    oled.clearDisplay();
    oled.setTextSize(1);

    oled.fillRect(0, 0, OLED_W, 13, SSD1306_WHITE);
    oled.setTextColor(SSD1306_BLACK);
    oled.setCursor(2, 3);
    oled.print(armed ? "ARMED  " : "DISARMD");
    oled.setCursor(68, 3);
    oled.print(STATE_NAME[sysState]); 
    oled.setTextColor(SSD1306_WHITE);

    oled.setCursor(0, 16);

    if (rDist >= 999)
        oled.println("Dist:  --- cm");
    else {
        snprintf(buf, sizeof(buf), "Dist:  %3ld cm", rDist);
        oled.println(buf);
    }

    oled.println(rMotion ? "Motion: DETECTED" : "Motion: none    ");

    snprintf(buf, sizeof(buf), "Gas:  %4d", rGasAout);
    oled.print(buf);
    if      (rGasAout > GAS_CRITICAL) oled.println(" CRIT");
    else if (rGasAout > GAS_WARNING)  oled.println(" WARN");
    else if (rGasAout > GAS_ALERT_LOW)oled.println(" ALRT");
    else                               oled.println(" OK  ");

    oled.println(rFlame ? "Flame:  DETECTED" : "Flame:  none    ");

    if (sensorFault) {
        oled.println("T:--.- C  H:--%  ");
    } else {
        int tw = (int)rTemp;
        int tf = abs((int)((rTemp - tw) * 10.0f));
        int hw = (int)rHum;
        snprintf(buf, sizeof(buf), "T:%d.%dC  H:%d%%", tw, tf, hw);
        oled.println(buf);
    }

    if (sensorFault) {
        oled.println("!! SENSOR FAULT !!");
    }

    oled.drawRect(0, 57, OLED_W, 7, SSD1306_WHITE);
    if (sysState > STATE_SAFE) {
        int bw = (OLED_W * (int)sysState) / 3;
        oled.fillRect(1, 58, bw - 1, 5, SSD1306_WHITE);
    }

    oled.display();
}

void mqttPub(const char* feed, const char* value) {
    if (!mqtt.connected()) return;
    char topic[80];
    snprintf(topic, sizeof(topic), "%s/feeds/%s", AIO_USERNAME, feed);
    mqtt.publish(topic, value);
}

void publishAll() {
    char buf[16];
    snprintf(buf, sizeof(buf), "%ld",  rDist);         mqttPub("distance", buf);
    mqttPub("motion",    rMotion      ? "1" : "0");
    snprintf(buf, sizeof(buf), "%d",   rGasAout);      mqttPub("gas",      buf);
    mqttPub("flame",     rFlame       ? "1" : "0");
    mqttPub("fault",     sensorFault  ? "1" : "0");
    int tw = (int)rTemp;
    int tf = abs((int)((rTemp - tw) * 10.0f));
    snprintf(buf, sizeof(buf), "%d.%d", tw, tf);       mqttPub("temp",     buf);
    snprintf(buf, sizeof(buf), "%d",   (int)rHum);    mqttPub("humidity", buf);
    snprintf(buf, sizeof(buf), "%d",   (int)sysState); mqttPub("state",    buf);
    mqttPub("armed",  armed ? "1" : "0");
    mqttPub("status", "online");
}

void mqttRun() {
    if (WiFi.status() != WL_CONNECTED) return;
    if (mqtt.connected()) { mqtt.loop(); return; }
    if (millis() - tMqtt < MS_MQTT_RETRY) return;
    tMqtt = millis();
    Serial.print("[MQTT] Connecting...");
    char will[80];
    snprintf(will, sizeof(will), "%s/feeds/status", AIO_USERNAME);
    bool ok = mqtt.connect("ESP32HomeSec", AIO_USERNAME, AIO_KEY,
                           will, 1, true, "offline");
    if (ok) { Serial.println("connected"); mqttPub("status", "online"); }
    else    { Serial.printf("failed rc=%d\n", mqtt.state()); }
}

void debugLine() {
    int tw = (int)rTemp;
    int tf = abs((int)((rTemp - tw) * 10.0f));
    Serial.printf(
        "[%5lus] D:%ldcm PIR:%d GAS:a%d,d%d "
        "FLAME:a%d,d%d=%d T:%d.%dC H:%d%% "
        "FAULT:%d | %s | Armed:%d\n",
        millis()/1000, rDist,
        rMotion ? 1 : 0,
        rGasAout, rGasDout ? 1 : 0,
        rFlameAout, rFlameDout ? 1 : 0, rFlame ? 1 : 0,
        tw, tf, (int)rHum,
        sensorFault ? 1 : 0,
        STATE_NAME[sysState],
        armed ? 1 : 0
    );
}

void connectWiFi() {
    Serial.printf("[WiFi] Connecting to: %s\n", WIFI_SSID);
    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASS);
    int n = 0;
    while (WiFi.status() != WL_CONNECTED && n++ < 20) {
        delay(500); Serial.print(".");
    }
    Serial.println();
    if (WiFi.status() == WL_CONNECTED)
        Serial.printf("[WiFi] Connected IP: %s\n", WiFi.localIP().toString().c_str());
    else
        Serial.println("[WiFi] Failed — offline mode");
}

void setup() {
    Serial.begin(115200);
    delay(300);
    Serial.println("================================");
    Serial.println("  HOME SECURITY SYSTEM  ESP32  ");
    Serial.println("================================");

    pinMode(PIN_TRIG,       OUTPUT); digitalWrite(PIN_TRIG,       LOW);
    pinMode(PIN_RELAY1,     OUTPUT); digitalWrite(PIN_RELAY1,     HIGH); // relays active LOW
    pinMode(PIN_RELAY2,     OUTPUT); digitalWrite(PIN_RELAY2,     HIGH);
    pinMode(PIN_LED_GREEN,  OUTPUT); digitalWrite(PIN_LED_GREEN,  LOW);
    pinMode(PIN_LED_YELLOW, OUTPUT); digitalWrite(PIN_LED_YELLOW, LOW);
    pinMode(PIN_LED_ORANGE, OUTPUT); digitalWrite(PIN_LED_ORANGE, LOW);
    pinMode(PIN_LED_RED,    OUTPUT); digitalWrite(PIN_LED_RED,    LOW);
  
    pinMode(PIN_ECHO,   INPUT);
    pinMode(PIN_PIR,    INPUT);
    pinMode(PIN_BUTTON, INPUT);

    dht.begin();
    Serial.println("[DHT22] started");

    Wire.begin(PIN_SDA, PIN_SCL);
    if (!oled.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
        Serial.println("[OLED] NOT FOUND — check wiring");
    } else {
        Serial.println("[OLED] OK");
        oled.clearDisplay();
        oled.setTextColor(SSD1306_WHITE);
        oled.setTextSize(1);
        oled.setCursor(10, 8);  oled.println("Home Security v3");
        oled.setCursor(10, 24); oled.println("Initialising...");
        oled.display();
    }

    connectWiFi();

    oled.clearDisplay();
    oled.setCursor(0, 8);
    if (WiFi.status() == WL_CONNECTED) {
        oled.println("WiFi OK");
        oled.println(WiFi.localIP().toString().c_str());
    } else {
        oled.println("WiFi FAILED");
        oled.println("Offline mode");
    }
    oled.display();
    delay(1500);

    mqtt.setServer(AIO_SERVER, AIO_PORT);
    mqtt.setBufferSize(512);

    int leds[] = {
        PIN_LED_GREEN, PIN_LED_YELLOW, 
        PIN_LED_ORANGE,   PIN_LED_RED,    
    };
    for (int p : leds) { digitalWrite(p, HIGH); delay(150); digitalWrite(p, LOW); }

    buzPlay(STATE_SAFE);
    digitalWrite(PIN_LED_GREEN, HIGH);  

    Serial.println("[BOOT] Ready — press button to ARM/DISARM");
    Serial.println("LED map: GRN=safe  YLW=alert/motion  ORG=warning/fault  RED=critical");
    Serial.println("------------------------------------------------------------------");
}

// ── Loop ───────────────────────────────────────────────────────
void loop() {
    unsigned long now = millis();

    buzRun();
    mqttRun();

    bool btnNow = (digitalRead(PIN_BUTTON) == HIGH);
    if (btnNow && !lastBtn && (now - tBtn) > MS_DEBOUNCE) {
        tBtn  = now;
        armed = !armed;
        Serial.printf("[BTN] System %s\n", armed ? "ARMED" : "DISARMED");
        buzPlay(STATE_SAFE);
        if (!armed) {
            sysState = STATE_SAFE;
            setLEDs();
            setRelays();
        }
    }
    lastBtn = btnNow;

    if (now - tSensor >= MS_SENSOR) {
        tSensor = now;

        readAllSensors();               // 1. read hardware
        sysState = classifyState();     // 2. derive state from readings

        
        if (sysState != lastState) {
            lastState = sysState;
            Serial.printf("[STATE] → %s\n", STATE_NAME[sysState]);
            if (armed) buzPlay(sysState);
        }

        setLEDs();     
        setRelays(); 
        drawOLED();
        debugLine();
    }

    if (now - tPublish >= MS_PUBLISH) {
        tPublish = now;
        if (mqtt.connected()) {
            publishAll();
            Serial.println("[MQTT] Published");
        }
    }
}