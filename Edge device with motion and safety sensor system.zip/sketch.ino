
#include <DHT.h>
#include <LiquidCrystal_I2C.h>

#define PIR1_PIN     2
#define PIR2_PIN     3
#define DHT_PIN      4
#define RED_LED      7
#define BUZZER_PIN   8
#define ZONE1_LIGHT  9
#define ZONE2_LIGHT  10
#define GAS_PIN      A0
#define FLOOD_PIN    A1

#define GAS_THRESHOLD    500   
#define FLOOD_THRESHOLD  600   
#define TEMP_LIMIT       40.0 
#define LIGHT_TIMEOUT    8000  
#define ADAPTIVE_WINDOW  10000 

DHT dht(DHT_PIN, DHT22);
LiquidCrystal_I2C lcd(0x27, 16, 2);

byte alertChar[8] = {
  0b00100, 0b01110, 0b01110,
  0b11111, 0b11111, 0b00100,
  0b00100, 0b00000
};
byte okChar[8] = {
  0b00000, 0b00001, 0b00011,
  0b10110, 0b11100, 0b01000,
  0b00000, 0b00000
};

volatile bool motionZone1 = false;
volatile bool motionZone2 = false;

bool zone1Active  = false;
bool zone2Active  = false;
unsigned long zone1Timer = 0;
unsigned long zone2Timer = 0;

int  motionCount   = 0;
unsigned long adaptiveWindowStart = 0;
int  zone1Brightness = 150;
int  zone2Brightness = 150;

bool faultGas   = false;
bool faultHeat  = false;
bool faultFlood = false;
bool anyFault   = false;

unsigned long lastLCDUpdate = 0;
#define LCD_REFRESH 1500

void onMotionZone1() {
  motionZone1 = true;
}

void onMotionZone2() {
  motionZone2 = true;
}

void logEvent(const char* level, const String& msg) {
  unsigned long secs = millis() / 1000;
  unsigned long mins = secs / 60;
  secs = secs % 60;

  Serial.print("[");
  if (mins < 10) Serial.print("0");
  Serial.print(mins);
  Serial.print(":");
  if (secs < 10) Serial.print("0");
  Serial.print(secs);
  Serial.print("] [");
  Serial.print(level);
  Serial.print("] ");
  Serial.println(msg);
}

void triggerAlert(const char* faultType, int freq, int beeps, int onMs, int offMs) {
  digitalWrite(RED_LED, HIGH);
  for (int i = 0; i < beeps; i++) {
    tone(BUZZER_PIN, freq, onMs);
    delay(onMs);
    noTone(BUZZER_PIN);
    delay(offMs);
    if (i % 2 == 0) {
      digitalWrite(RED_LED, LOW);
    } else {
      digitalWrite(RED_LED, HIGH);
    }
  }
}

int calcAdaptiveBrightness() {
  unsigned long now = millis();
  if (now - adaptiveWindowStart > ADAPTIVE_WINDOW) {
    motionCount = 0;
    adaptiveWindowStart = now;
  }
  int brightness = constrain(map(motionCount, 0, 8, 90, 255), 90, 255);
  return brightness;
}

void updateLCD(int gasVal, float temp, bool fault, const char* faultMsg) {
  lcd.clear();
  lcd.setCursor(0, 0);
  if (fault) {
    lcd.write(0);       
    lcd.print(" ");
    lcd.print(faultMsg);
  } else {
    lcd.write(1);          
    lcd.print(" SYS: NORMAL");
  }
  lcd.setCursor(0, 1);
  lcd.print("G:");
  lcd.print(gasVal);
  lcd.print(" T:");
  if (!isnan(temp)) {
    lcd.print((int)temp);
    lcd.print("C");
  } else {
    lcd.print("--C");
  }

  if (zone1Active || zone2Active) {
    lcd.setCursor(11, 1);
    lcd.print(" LIT");
  }
}

void setup() {
  Serial.begin(9600);

  pinMode(PIR1_PIN,    INPUT);
  pinMode(PIR2_PIN,    INPUT);
  pinMode(RED_LED,     OUTPUT);
  pinMode(BUZZER_PIN,  OUTPUT);
  pinMode(ZONE1_LIGHT, OUTPUT);
  pinMode(ZONE2_LIGHT, OUTPUT);

  dht.begin();

  lcd.init();
  lcd.backlight();
  lcd.createChar(0, alertChar);
  lcd.createChar(1, okChar);

  lcd.setCursor(0, 0);
  lcd.print("Smart Home v1.0");
  lcd.setCursor(0, 1);
  lcd.print("Booting...");
  delay(1500);

  attachInterrupt(digitalPinToInterrupt(PIR1_PIN), onMotionZone1, RISING);
  attachInterrupt(digitalPinToInterrupt(PIR2_PIN), onMotionZone2, RISING);

  adaptiveWindowStart = millis();

  logEvent("INFO", "System ready. All zones online.");
  logEvent("INFO", "Monitoring: Gas | Flood | Heat | Motion x2");
}

void loop() {
  unsigned long now = millis();

  int  gasLevel   = analogRead(GAS_PIN);
  int  floodLevel = analogRead(FLOOD_PIN);
  float temp      = dht.readTemperature();

  faultGas   = (gasLevel   > GAS_THRESHOLD);
  faultHeat  = (!isnan(temp) && temp > TEMP_LIMIT);
  faultFlood = (floodLevel > FLOOD_THRESHOLD);
  anyFault   = faultGas || faultHeat || faultFlood;

  if (anyFault) {
    analogWrite(ZONE1_LIGHT, 0);
    analogWrite(ZONE2_LIGHT, 0);
    zone1Active = false;
    zone2Active = false;
    motionZone1 = false;
    motionZone2 = false;

    if (faultGas) {
      triggerAlert("GAS", 1000, 2, 200, 150);
      logEvent("FAULT", "GAS DETECTED — level: " + String(gasLevel) + "/1023. Override active.");
    }

    if (faultHeat) {
      triggerAlert("HEAT", 700, 3, 250, 100);
      logEvent("FAULT", "OVER-HEAT — temp: " + String(temp) + "C. Override active.");
    }

    if (faultFlood) {
      triggerAlert("FLOOD", 400, 4, 300, 200);
      logEvent("FAULT", "FLOOD DETECTED — level: " + String(floodLevel) + "/1023. Override active.");
    }

    digitalWrite(RED_LED, HIGH);

    if (now - lastLCDUpdate > LCD_REFRESH) {
      const char* faultLabel = faultGas ? "GAS FAULT" : (faultHeat ? "HEAT FAULT" : "FLOOD FAULT");
      updateLCD(gasLevel, temp, true, faultLabel);
      lastLCDUpdate = now;
    }

    delay(200);
    return; 
  }

  if (!anyFault) {
    static bool wasInFault = false;
    if (wasInFault) {
      digitalWrite(RED_LED, LOW);
      noTone(BUZZER_PIN);
      logEvent("INFO", "All faults cleared. System nominal.");
      wasInFault = false;
    }
    bool currentFault = faultGas || faultHeat || faultFlood;
    if (currentFault) wasInFault = true;
  }

  if (motionZone1) {
    motionZone1  = false;
    zone1Active  = true;
    zone1Timer   = now;
    motionCount++;
    zone1Brightness = calcAdaptiveBrightness();
    logEvent("INFO", "Zone 1 motion → Lights ON (brightness: " + String(zone1Brightness) + ")");
  }

  if (motionZone2) {
    motionZone2  = false;
    zone2Active  = true;
    zone2Timer   = now;
    motionCount++;
    zone2Brightness = calcAdaptiveBrightness();
    logEvent("INFO", "Zone 2 motion → Lights ON (brightness: " + String(zone2Brightness) + ")");
  }

  if (zone1Active && (now - zone1Timer > LIGHT_TIMEOUT)) {
    zone1Active = false;
    analogWrite(ZONE1_LIGHT, 0);
    logEvent("INFO", "Zone 1 timeout → Lights OFF");
  }

  if (zone2Active && (now - zone2Timer > LIGHT_TIMEOUT)) {
    zone2Active = false;
    analogWrite(ZONE2_LIGHT, 0);
    logEvent("INFO", "Zone 2 timeout → Lights OFF");
  }

  if (zone1Active) analogWrite(ZONE1_LIGHT, zone1Brightness);
  if (zone2Active) analogWrite(ZONE2_LIGHT, zone2Brightness);

  if (now - lastLCDUpdate > LCD_REFRESH) {
    updateLCD(gasLevel, temp, false, "");
    lastLCDUpdate = now;
  }

  delay(80);
}
