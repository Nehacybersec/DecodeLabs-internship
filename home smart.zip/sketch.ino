//   ESP32 Home Automation 
//   LCD + OLED + RGB LED + NeoPixel + Buzzer + DHT22

#include <Wire.h>
#include <DHT.h>
#include <Adafruit_NeoPixel.h>
#include <LiquidCrystal_I2C.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

//Pins
#define DHT_PIN       4
#define DHT_TYPE      DHT22
#define NEO_PIN       15
#define NEO_COUNT     16
#define BUZZER_PIN    18
#define RGB_R         27
#define RGB_G         25
#define RGB_B         26

//I2C Addresses
#define LCD_ADDR      0x27   // LCD  → 0x27
#define OLED_ADDR     0x3C   // OLED → 0x3C  (different address!)

//OLED Size
#define OLED_W        128
#define OLED_H        64

//Temperature
#define TEMP_COLD     14.0
#define TEMP_WARNING  28.0
#define TEMP_DANGER   35.0
#define HUM_WARNING   57.0
#define HUM_DANGER    75.0
#define READ_INTERVAL 2000

//Objects
DHT               dht(DHT_PIN, DHT_TYPE);
Adafruit_NeoPixel ring(NEO_COUNT, NEO_PIN, NEO_GRB + NEO_KHZ800);
LiquidCrystal_I2C lcd(LCD_ADDR, 16, 2);
Adafruit_SSD1306  oled(OLED_W, OLED_H, &Wire, -1);

//State
float         temperature = 25.0;
float         humidity    = 50.0;
int           alertLevel  = 0;
int           spinIdx     = 0;
unsigned long lastRead    = 0;
bool          oledOK      = false;

//Custom LCD Characters
byte degChar[8]   = {0b00110,0b01001,0b01001,0b00110,
                     0b00000,0b00000,0b00000,0b00000};
byte alertChar[8] = {0b00100,0b01110,0b01110,0b11111,
                     0b11111,0b01110,0b00100,0b00000};

//   SETUP

void setup() {
  Serial.begin(115200);
  delay(1000);  // Give everything time to power up
  Serial.println(F("\n=== ESP32 Home Automation ==="));

  //RGB LED
  pinMode(RGB_R, OUTPUT);
  pinMode(RGB_G, OUTPUT);
  pinMode(RGB_B, OUTPUT);
  setRGB(0, 0, 0);   
  Serial.println(F("[OK] RGB LED ready on GPIO 25/26/27"));

 // RGB test — runs at boot so you can see it working
  Serial.println(F("[TEST] RGB testing now..."));
  setRGB(1, 0, 0); delay(500);  // Red
  setRGB(0, 1, 0); delay(500);  // Green
  setRGB(0, 0, 1); delay(500);  // Blue
  setRGB(0, 0, 0);              // OFF
  Serial.println(F("[TEST] RGB done!"));

  //Buzzer 
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  Serial.println(F("[OK] Buzzer ready"));

  //DHT22
  dht.begin();
  Serial.println(F("[OK] DHT22 ready"));

  //NeoPixel
  ring.begin();
  ring.setBrightness(80);
  ring.clear();
  ring.show();
  Serial.println(F("[OK] NeoPixel ready"));

  //I2C Bus
  Wire.begin(21, 22);
  delay(100);
  Serial.println(F("[OK] I2C bus started on SDA=21 SCL=22"));

  //LCD Init 
  lcd.init();
  delay(100);
  lcd.backlight();
  lcd.createChar(0, degChar);
  lcd.createChar(1, alertChar);
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(F("  Home Monitor  "));
  lcd.setCursor(0, 1);
  lcd.print(F("  Loading...    "));
  Serial.println(F("[OK] LCD ready at 0x27"));

  //OLED Init
  if (oled.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    oledOK = true;
    oled.clearDisplay();
    oled.setTextColor(SSD1306_WHITE);
    oled.setTextSize(1);
    oled.setCursor(20, 25);
    oled.print(F("Home Automation"));
    oled.display();
    Serial.println(F("[OK] OLED ready at 0x3C"));
  } else {
    oledOK = false;
    Serial.println(F("[WARN] OLED not found — skipping"));
  }

  //Boot Animation
  bootAnimation();

  Serial.println(F("\n[READY] System running!\n"));
}

//   MAIN LOOP
void loop() {
  if (millis() - lastRead >= READ_INTERVAL) {
    lastRead = millis();
    readSensor();
    determineAlert();
    updateLEDs();
    updateBuzzer();
    updateNeoPixel();
    updateLCD();
    if (oledOK) updateOLED();
    printSerial();
  }
}

//   READ DHT22
void readSensor() {
  float t = dht.readTemperature();
  float h = dht.readHumidity();

  if (isnan(t) || isnan(h)) {
    Serial.println(F("[ERROR] DHT22 failed! Check GPIO 4."));

    lcd.clear();
    lcd.setCursor(0, 0); lcd.print(F("  SENSOR ERROR! "));
    lcd.setCursor(0, 1); lcd.print(F("  Check GPIO 4  "));

    if (oledOK) {
      oled.clearDisplay();
      oled.setTextSize(2);
      oled.setCursor(5, 20);
      oled.print(F("SENSOR"));
      oled.setCursor(5, 42);
      oled.print(F("ERROR!"));
      oled.display();
    }

    // Flash red + beep 3 times
    for (int i = 0; i < 3; i++) {
      setRGB(1, 0, 0);
      ring.fill(ring.Color(255, 0, 0)); ring.show();
      tone(BUZZER_PIN, 1000); delay(300);
      setRGB(0, 0, 0);
      ring.clear(); ring.show();
      noTone(BUZZER_PIN); delay(200);
    }
    return;
  }

  temperature = t;
  humidity    = h;
}

//   DETERMINE ALERT LEVEL
void determineAlert() {
  bool danger  = (temperature >= TEMP_DANGER)  || (humidity >= HUM_DANGER);
  bool warning = (temperature >= TEMP_WARNING) || (humidity >= HUM_WARNING)
                 || (temperature < TEMP_COLD);

  if      (danger)  alertLevel = 2;
  else if (warning) alertLevel = 1;
  else              alertLevel = 0;
}

//   RGB LED
void setRGB(bool r, bool g, bool b) {
  digitalWrite(RGB_R, r ? HIGH : LOW);
  digitalWrite(RGB_G, g ? HIGH : LOW);
  digitalWrite(RGB_B, b ? HIGH : LOW);
}

void updateLEDs(){
  setRGB(0, 0, 0);  // ← turn all OFF first always

  if (temperature < TEMP_COLD) {
    setRGB(0, 0, 1);
    Serial.println(F("[RGB] BLUE — Cold"));
  } else if (alertLevel == 0) {
    setRGB(0, 1, 0);
    Serial.println(F("[RGB] GREEN — Safe"));
  } else if (alertLevel == 1) {
    setRGB(1, 1, 0);
    Serial.println(F("[RGB] YELLOW — Warning"));
  } else {
    setRGB(1, 0, 0);
    Serial.println(F("[RGB] RED — Danger!"));
  }
}

//   BUZZER
void updateBuzzer() {
  noTone(BUZZER_PIN);
  if (alertLevel == 2) {
    for (int i = 0; i < 3; i++) {
      tone(BUZZER_PIN, 2000); delay(150);
      noTone(BUZZER_PIN);     delay(100);
    }
  } else if (alertLevel == 1) {
    tone(BUZZER_PIN, 1000); delay(300);
    noTone(BUZZER_PIN);
  }
}

//NEOPIXEL RING
void updateNeoPixel() {
  uint32_t col;
  if      (temperature < TEMP_COLD)    col = ring.Color(0,   0,   255);
  else if (temperature < TEMP_WARNING) col = ring.Color(0,   200, 0);
  else if (temperature < TEMP_DANGER)  col = ring.Color(255, 180, 0);
  else                                 col = ring.Color(255, 0,   0);

  if (alertLevel == 0) {
    ring.fill(col);
    ring.show();
  } else if (alertLevel == 1) {
    static bool pulse = true;
    ring.fill(pulse ? col : ring.Color(
      (col >> 16 & 0xFF) / 4,
      (col >> 8  & 0xFF) / 4,
      (col & 0xFF) / 4));
    ring.show();
    pulse = !pulse;
  } else {
    for (int i = 0; i < NEO_COUNT; i++)
      ring.setPixelColor(i, (i == spinIdx) ? ring.Color(10,10,10) : col);
    ring.show();
    spinIdx = (spinIdx + 1) % NEO_COUNT;
  }
}

//LCD16x2
void updateLCD() {
  String status;
  if      (temperature < TEMP_COLD) status = "COLD! ";
  else if (alertLevel == 0)         status = "Safe  ";
  else if (alertLevel == 1)         status = "WARN! ";
  else                              status = "DANGER";

  lcd.clear();

  // Row 0 — Temperature
  lcd.setCursor(0, 0);
  lcd.print(F("T:"));
  lcd.print(temperature, 1);
  lcd.write(byte(0));   // degree °
  lcd.print(F("C"));
  if (alertLevel > 0) {
    lcd.setCursor(11, 0);
    lcd.write(byte(1)); // alert !
    lcd.print(F(" !!"));
  }

  // Row 1 — Humidity + Status
  lcd.setCursor(0, 1);
  lcd.print(F("H:"));
  lcd.print(humidity, 1);
  lcd.print(F("%"));
  lcd.setCursor(16 - status.length(), 1);
  lcd.print(status);
}

//OLED 
void updateOLED() {
  oled.clearDisplay();

  //Title bar 
  oled.fillRect(0, 0, 128, 13, SSD1306_WHITE);
  oled.setTextColor(SSD1306_BLACK);
  oled.setTextSize(1);
  oled.setCursor(22, 3);
  oled.print(F("HOME MONITOR"));

  oled.setTextColor(SSD1306_WHITE);

  //Temperature
  oled.setTextSize(1);
  oled.setCursor(0, 17);
  oled.print(F("TEMP:"));
  oled.setTextSize(2);
  oled.setCursor(40, 15);
  oled.print(temperature, 1);
  oled.setTextSize(1);
  oled.setCursor(105, 15);
  oled.print(F("oC"));

  // Temperature bar
  int tBar = constrain(map((int)temperature, 0, 50, 0, 100), 0, 100);
  oled.drawRect(0, 30, 102, 7, SSD1306_WHITE);
  oled.fillRect(1, 31, tBar, 5, SSD1306_WHITE);

  // Zone markers
 oled.drawLine(map(TEMP_COLD,    0,50, 0,100), 30,
              map(TEMP_COLD,    0,50, 0,100), 37, SSD1306_WHITE);
 oled.drawLine(map(TEMP_WARNING, 0,50, 0,100), 30,
              map(TEMP_WARNING, 0,50, 0,100), 37, SSD1306_WHITE);
 oled.drawLine(map(TEMP_DANGER,  0,50, 0,100), 30,
              map(TEMP_DANGER,  0,50, 0,100), 37, SSD1306_WHITE);

  //Humidity
  oled.setTextSize(1);
  oled.setCursor(0, 42);
  oled.print(F("HUM:"));
  oled.setCursor(30, 42);
  oled.print(humidity, 1);
  oled.print(F("%"));

  // Humidity bar
  int hBar = constrain(map((int)humidity, 0, 100, 0, 100), 0, 100);
  oled.drawRect(0, 53, 102, 7, SSD1306_WHITE);
  oled.fillRect(1, 54, hBar, 5, SSD1306_WHITE);

  //Status (right side)
  oled.setTextSize(1);
  oled.setCursor(108, 20);
  if      (alertLevel == 0) { oled.print(F("OK")); }
  else if (alertLevel == 1) { oled.print(F("!!")); }
  else                      { oled.print(F("SOS")); }

  oled.display();
}

//SERIAL MONITOR
void printSerial() {
  String lvl = (alertLevel==0) ? "SAFE" :
               (alertLevel==1) ? "WARNING" : "DANGER!";
  Serial.println(F("┌──────────────────────────────┐"));
  Serial.print(F("│ Temp     : ")); Serial.print(temperature,1);
  Serial.println(F(" C                  |"));
  Serial.print(F("│ Humidity : ")); Serial.print(humidity,1);
  Serial.println(F(" %                  |"));
  Serial.print(F("│ Alert    : ")); Serial.println(lvl);
  Serial.println(F("└──────────────────────────────┘\n"));
}

//BOOT ANIMATION
void bootAnimation() {
  // Rainbow on NeoPixel
  for (int j = 0; j < 256; j += 4) {
    for (int i = 0; i < NEO_COUNT; i++) {
      ring.setPixelColor(i, ring.gamma32(
        ring.ColorHSV((i * 65536L / NEO_COUNT + j * 256) & 0xFFFF)));
    }
    ring.show();
    delay(8);
  }

  //RGB color
  setRGB(1, 0, 0); delay(400);  // Red   ← 80 changed to 400
  setRGB(0, 1, 0); delay(400);  // Green ← so you can see each color
  setRGB(0, 0, 1); delay(400);  // Blue
  setRGB(1, 1, 0); delay(400);  // Yellow
  setRGB(1, 0, 1); delay(400);  // Purple
  setRGB(0, 1, 1); delay(400);  // Cyan
  setRGB(1, 1, 1); delay(400);  // White
  setRGB(0, 0, 0);              // OFF 

  //Buzzer chirp
  tone(BUZZER_PIN, 1500); delay(80);
  tone(BUZZER_PIN, 2000); delay(80);
  tone(BUZZER_PIN, 2500); delay(80);
  noTone(BUZZER_PIN);

  delay(300);
  lcd.clear();
}