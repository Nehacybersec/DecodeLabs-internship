#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>

//PIN CONFIG 
#define SOIL_MOISTURE_PIN    34
#define DHT_SENSOR_PIN       4
#define WATER_PUMP_RELAY_PIN 26
#define RGB_RED_PIN          25
#define RGB_GREEN_PIN        27
#define RGB_BLUE_PIN         32
#define BUZZER_PIN           33
#define MODE_BUTTON_PIN      14

//DISPLAY CONFIG 
#define OLED_WIDTH       128
#define OLED_HEIGHT      64
#define OLED_I2C_ADDR    0x3C
#define LCD_I2C_ADDR     0x27
#define LCD_COLS         16
#define LCD_ROWS         2

//SOIL THRESHOLDS 
#define SOIL_DRY         35
#define SOIL_WET         60
#define SOIL_FERT_LOW    30
#define SOIL_FERT_HIGH   70

//TANK
#define TANK_LEVEL       75   

//CROP TEMP RANGES 
#define TEMP_SPINACH     10.0
#define TEMP_POTATO      18.0
#define TEMP_WHEAT       24.0
#define TEMP_MAIZE       30.0
#define TEMP_RICE        36.0

//TIMING 
#define BTN_DEBOUNCE_MS      400
#define LCD_ROTATE_MS        3000
#define LOOP_DELAY_MS        500
#define BUZZER_INTERVAL_MS   2500
#define LCD_SCREENS          4

//BUZZER FREQ
#define FREQ_ALERT    1000
#define FREQ_CONFIRM  2000

//OBJECTS 
Adafruit_SSD1306   oled(OLED_WIDTH, OLED_HEIGHT, &Wire, -1);
LiquidCrystal_I2C  lcd(LCD_I2C_ADDR, LCD_COLS, LCD_ROWS);
DHT                dht(DHT_SENSOR_PIN, DHT22);

//STATE VARIABLES 
bool autoMode       = true;
bool pumpActive     = false;
bool tankAlert      = false;
bool soilDryAlert   = false;   // NEW: tracks dry-soil condition for buzzer
int  lcdScreen      = 0;
float lastTemp      = 25.0;
float lastHum       = 50.0;

unsigned long lastLcdRotate  = 0;
unsigned long lastBuzzerTime = 0;

//SENSOR DATA 
struct SensorData {
  int   soilMoisture;
  int   tankLevel;
  float temperature;
  float humidity;
  bool  dhtOk;
};

//FORWARD DECLARATIONS 
SensorData readAllSensors();
void runIrrigationLogic(const SensorData& d);
void updateRGB(const SensorData& d);
void updateOLED(const SensorData& d);
void updateLCD(const SensorData& d);
void serialReport(const SensorData& d);
void handleBuzzer(bool alert);
void handleButton();
void buzzerBeep(int freqHz, int durationMs);
void buzzerStop();
void setRGB(bool r, bool g, bool b);
String soilLabel(int s);
String fertLabel(int s);
String cropLabel(float t);
String tankLabel(int t);
bool   initOLED();
void   initLCD();
void   oledBoot();
void   lcdBoot();

//SETUP
void setup() {

  Serial.begin(115200);
  delay(500);
  Serial.println("\n========== Smart Irrigation Boot ==========");

  // Output pins
  pinMode(WATER_PUMP_RELAY_PIN, OUTPUT);
  pinMode(RGB_RED_PIN,          OUTPUT);
  pinMode(RGB_GREEN_PIN,        OUTPUT);
  pinMode(RGB_BLUE_PIN,         OUTPUT);
  pinMode(BUZZER_PIN,           OUTPUT);

  // Input pins
  pinMode(MODE_BUTTON_PIN, INPUT_PULLUP);

  // Safe defaults
  digitalWrite(WATER_PUMP_RELAY_PIN, LOW);
  digitalWrite(BUZZER_PIN,           LOW);
  setRGB(false, false, false);

  Wire.begin(21, 22);
  dht.begin();
  Serial.println("[OK] DHT22 ready");

  // OLED init
  if (!initOLED()) {
    Serial.println("[ERR] OLED failed");
  } else {
    Serial.println("[OK] OLED ready");
    oledBoot();
  }

  // LCD init
  initLCD();
  Serial.println("[OK] LCD ready");
  lcdBoot();

  // Buzzer startup test
  delay(500);
  buzzerBeep(FREQ_CONFIRM, 150);
  delay(150);
  buzzerBeep(FREQ_CONFIRM, 150);
  Serial.println("[OK] Buzzer ready");

  delay(1500);
  Serial.println("[OK] System started\n");
}

// MAIN LOO
void loop() {

  handleButton();

  SensorData data = readAllSensors();

  // Cache last valid DHT values
  if (data.dhtOk) {
    lastTemp = data.temperature;
    lastHum  = data.humidity;
  }

  runIrrigationLogic(data);

  digitalWrite(WATER_PUMP_RELAY_PIN, pumpActive ? HIGH : LOW);

  updateRGB(data);
  updateOLED(data);
  updateLCD(data);
  handleBuzzer(tankAlert || soilDryAlert);   // UPDATED: both alerts feed the buzzer
  serialReport(data);

  delay(LOOP_DELAY_MS);
}

// SENSOR READING
SensorData readAllSensors() {

  SensorData d;

  // Soil moisture: high raw = dry soil
  int raw       = analogRead(SOIL_MOISTURE_PIN);
  d.soilMoisture = constrain(map(raw, 4095, 0, 0, 100), 0, 100);

  // Tank is simulated
  d.tankLevel = TANK_LEVEL;

  float t = dht.readTemperature();
  float h = dht.readHumidity();

  if (isnan(t) || isnan(h)) {
    d.dhtOk      = false;
    d.temperature = lastTemp;
    d.humidity    = lastHum;
    Serial.println("[WARN] DHT22 read failed, using cached values");
  } else {
    d.dhtOk      = true;
    d.temperature = t;
    d.humidity    = h;
  }

  return d;
}

//IRRIGATION LOGIC
void runIrrigationLogic(const SensorData& d) {

  // Tank critically low = pump off + alert
  if (d.tankLevel < 20) {
    pumpActive   = false;
    tankAlert    = true;
    soilDryAlert = false;   // tank alert takes priority
    return;
  }

  tankAlert = false;

  if (autoMode) {
    if (d.soilMoisture < SOIL_DRY) pumpActive = true;
    if (d.soilMoisture > SOIL_WET) pumpActive = false;
  }

  // NEW: flag dry soil regardless of auto/manual mode
  soilDryAlert = (d.soilMoisture < SOIL_DRY);
}

// RGB LED STATUS
void updateRGB(const SensorData& d) {

  if (d.soilMoisture < SOIL_DRY) {
    setRGB(true, false, false);   // RED = dry
  } else if (d.soilMoisture < SOIL_WET) {
    setRGB(true, true, false);    // YELLOW = moist
  } else {
    setRGB(false, true, false);   // GREEN = wet
  }
}

// OLED DISPLAY
void updateOLED(const SensorData& d) {

  oled.clearDisplay();
  oled.setTextColor(WHITE);
  oled.setTextSize(1);

  // Title
  oled.setCursor(0, 0);
  oled.print("SMART IRRIGATION SYS");
  oled.drawLine(0, 9, OLED_WIDTH, 9, WHITE);

  // Soil
  oled.setCursor(0, 12);
  oled.print("Soil : ");
  oled.print(d.soilMoisture);
  oled.print("% [");
  oled.print(soilLabel(d.soilMoisture));
  oled.print("]");

  // Tank
  oled.setCursor(0, 22);
  oled.print("Tank : ");
  oled.print(d.tankLevel);
  oled.print("% [");
  oled.print(tankLabel(d.tankLevel));
  oled.print("]");

  // Temperature
  oled.setCursor(0, 32);
  oled.print("Temp : ");
  if (d.dhtOk) {
    oled.print(d.temperature, 1);
    oled.print((char)247);
    oled.print("C");
  } else {
    oled.print("Error");
  }

  // Humidity
  oled.setCursor(0, 42);
  oled.print("Hum  : ");
  if (d.dhtOk) {
    oled.print(d.humidity, 1);
    oled.print("%");
  } else {
    oled.print("Error");
  }

  // Bottom status bar
  oled.drawLine(0, 53, OLED_WIDTH, 53, WHITE);
  oled.setCursor(0, 56);
  oled.print(autoMode ? "AUTO" : "MAN");
  oled.print("|Pump:");
  oled.print(pumpActive ? "ON" : "OFF");
  oled.print("|");
  oled.print(cropLabel(d.temperature));

  oled.display();
}

// LCD DISPLAY
void updateLCD(const SensorData& d) {

  // Rotate screen every LCD_ROTATE_MS
  if (millis() - lastLcdRotate >= LCD_ROTATE_MS) {
    lcdScreen = (lcdScreen + 1) % LCD_SCREENS;
    lastLcdRotate = millis();
    lcd.clear();
  }

  switch (lcdScreen) {

    case 0: // Soil & Tank
      lcd.setCursor(0, 0);
      lcd.print("Soil:");
      lcd.print(d.soilMoisture);
      lcd.print("% ");
      lcd.print(soilLabel(d.soilMoisture));

      lcd.setCursor(0, 1);
      lcd.print("Tank:");
      lcd.print(d.tankLevel);
      lcd.print("% ");
      lcd.print(tankLabel(d.tankLevel));
      break;

    case 1: // Pump & Alert
      lcd.setCursor(0, 0);
      lcd.print("Pump:");
      lcd.print(pumpActive ? "ON  " : "OFF ");
      lcd.print(autoMode ? "AUTO" : "MAN ");

      lcd.setCursor(0, 1);
      lcd.print("Alert:");
      if (tankAlert)        lcd.print("TANK EMPTY!");
      else if (soilDryAlert) lcd.print("SOIL DRY!  ");
      else                   lcd.print("None       ");
      break;

    case 2: // Climate
      lcd.setCursor(0, 0);
      lcd.print("Temp: ");
      if (d.dhtOk) {
        lcd.print(d.temperature, 1);
        lcd.print((char)223);
        lcd.print("C");
      } else {
        lcd.print("Sensor Err");
      }

      lcd.setCursor(0, 1);
      lcd.print("Hum:  ");
      if (d.dhtOk) {
        lcd.print(d.humidity, 1);
        lcd.print("%");
      } else {
        lcd.print("Sensor Err");
      }
      break;

    case 3: // Agri Info
      lcd.setCursor(0, 0);
      lcd.print("Fert: ");
      lcd.print(fertLabel(d.soilMoisture));

      lcd.setCursor(0, 1);
      lcd.print("Crop: ");
      lcd.print(cropLabel(d.temperature));
      break;
  }
}

//SERIAL REPORT
void serialReport(const SensorData& d) {

  Serial.println("+---------------------------+");
  Serial.println("|       SENSOR REPORT       |");
  Serial.println("+---------------------------+");
  Serial.print("| Soil    : "); Serial.print(d.soilMoisture);
  Serial.print("% [");         Serial.print(soilLabel(d.soilMoisture));
  Serial.println("]");
  Serial.print("| Tank    : "); Serial.print(d.tankLevel);
  Serial.print("% [");         Serial.print(tankLabel(d.tankLevel));
  Serial.println("]");
  Serial.print("| Temp    : ");
  if (d.dhtOk) { Serial.print(d.temperature, 1); Serial.println("C"); }
  else            Serial.println("Error");
  Serial.print("| Hum     : ");
  if (d.dhtOk) { Serial.print(d.humidity, 1); Serial.println("%"); }
  else            Serial.println("Error");
  Serial.print("| Pump    : "); Serial.println(pumpActive ? "ON"     : "OFF");
  Serial.print("| Mode    : "); Serial.println(autoMode   ? "AUTO"   : "MANUAL");
  Serial.print("| Crop    : "); Serial.println(cropLabel(d.temperature));
  Serial.print("| Fert    : "); Serial.println(fertLabel(d.soilMoisture));
  Serial.print("| Alert   : ");
  if (tankAlert)        Serial.println("TANK LOW - REFILL!");
  else if (soilDryAlert) Serial.println("SOIL DRY - IRRIGATE!");
  else                   Serial.println("None");
  Serial.println("+---------------------------+\n");
}

//BUZZER
void buzzerBeep(int freqHz, int durationMs) {

  if (freqHz <= 0) return;

  int  halfPeriod = 1000000 / (freqHz * 2); // microseconds
  long cycles     = (long)freqHz * durationMs / 1000;

  for (long i = 0; i < cycles; i++) {
    digitalWrite(BUZZER_PIN, HIGH);
    delayMicroseconds(halfPeriod);
    digitalWrite(BUZZER_PIN, LOW);
    delayMicroseconds(halfPeriod);
  }
}

void buzzerStop() {
  digitalWrite(BUZZER_PIN, LOW);
}

// UPDATED: now handles tank-critical AND soil-dry alerts with distinct patterns
void handleBuzzer(bool alert) {

  if (!alert) {
    buzzerStop();
    return;
  }

  unsigned long now = millis();
  if (now - lastBuzzerTime >= BUZZER_INTERVAL_MS) {
    lastBuzzerTime = now;

    if (tankAlert) {
      // Three short beeps for tank critical
      buzzerBeep(FREQ_ALERT, 150);
      delay(80);
      buzzerBeep(FREQ_ALERT, 150);
      delay(80);
      buzzerBeep(FREQ_ALERT, 150);
      Serial.println("[ALERT] Tank critically low!");
    } else if (soilDryAlert) {
      // One long beep for dry soil
      buzzerBeep(FREQ_ALERT, 400);
      Serial.println("[ALERT] Soil is dry!");
    }
  }
}

//LABEL FUNCTIONS
String soilLabel(int s) {
  if (s < SOIL_DRY)  return "DRY";
  if (s < SOIL_WET)  return "MOIST";
  return "WET";
}

String fertLabel(int s) {
  if (s < SOIL_FERT_LOW)  return "LOW";
  if (s < SOIL_FERT_HIGH) return "MEDIUM";
  return "HIGH";
}

String cropLabel(float t) {
  if (t < TEMP_SPINACH) return "SPINACH";   // Below 10C
  if (t < TEMP_POTATO)  return "POTATO";    // 10-18C
  if (t < TEMP_WHEAT)   return "WHEAT";     // 18-24C
  if (t < TEMP_MAIZE)   return "MAIZE";     // 24-30C
  if (t < TEMP_RICE)    return "RICE";      // 30-36C
  return "SUGARCANE";                       // Above 36C
}

String tankLabel(int t) {
  if (t < 20) return "CRITICAL";
  if (t < 40) return "LOW";
  if (t < 70) return "MODERATE";
  return "FULL";
}

//UTILITY FUNCTIONS
void setRGB(bool r, bool g, bool b) {
  digitalWrite(RGB_RED_PIN,   r ? HIGH : LOW);
  digitalWrite(RGB_GREEN_PIN, g ? HIGH : LOW);
  digitalWrite(RGB_BLUE_PIN,  b ? HIGH : LOW);
}

void handleButton() {
  if (digitalRead(MODE_BUTTON_PIN) == LOW) {
    autoMode = !autoMode;
    Serial.print("[INFO] Mode: ");
    Serial.println(autoMode ? "AUTO" : "MANUAL");
    buzzerBeep(FREQ_CONFIRM, 120);
    delay(BTN_DEBOUNCE_MS);
  }
}

bool initOLED() {
  return oled.begin(SSD1306_SWITCHCAPVCC, OLED_I2C_ADDR);
}

void initLCD() {
  lcd.init();
  lcd.backlight();
}

void oledBoot() {
  oled.clearDisplay();
  oled.setTextColor(WHITE);
  oled.setTextSize(2);
  oled.setCursor(10, 4);
  oled.print("SMART");
  oled.setCursor(4, 24);
  oled.print("IRRIGATE");
  oled.setTextSize(1);
  oled.setCursor(15, 50);
  oled.print("Initializing...");
  oled.display();
}

void lcdBoot() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(" Smart Irrigation");
  lcd.setCursor(0, 1);
  lcd.print("   System v2.0");
}
